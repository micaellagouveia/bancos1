-- --------     << aula9extra1 >>     ------------
-- 
-- SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 07/04/2021
-- Autor(es) ..............: Micaella Lorraine Gouveia de Lima
-- Banco de Dados .........: MySQL 8.0.23
-- Banco de Dados(nome) ...: aula9extra1
-- 
-- PROJETO => 01 Base de Dados
--         => 02 Tabelas
-- -----------------------------------------------------------------

USE aula9extra1;

DROP TABLE CIDADE;
DROP TABLE ESTADO;