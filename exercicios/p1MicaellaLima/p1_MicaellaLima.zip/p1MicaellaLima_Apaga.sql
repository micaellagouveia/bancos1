-- --------     << P1 >>     ------------
-- 
-- SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 06/04/2021
-- Autor(es) ..............: Micaella Lorraine Gouveia de Lima
-- Banco de Dados .........: MySQL 8.0.23
-- Banco de Dados(nome) ...: MicaellaLima
-- 
-- PROJETO => 01 Base de Dados
--         => 05 Tabelas
-- -----------------------------------------------------------------

USE MicaellaLima;

DROP TABLE possui;
DROP TABLE relaciona;
DROP TABLE INTERESSE;
DROP TABLE email;
DROP TABLE INTERNAUTA;