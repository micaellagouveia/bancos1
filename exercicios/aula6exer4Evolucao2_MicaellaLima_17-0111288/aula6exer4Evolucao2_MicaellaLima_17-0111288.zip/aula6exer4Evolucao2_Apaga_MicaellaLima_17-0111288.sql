-- --------      aula6exer4Evolucao2      ------------
--
--                    SCRIPT DE APAGA (DDL)
--
-- Data Criacao ........... 27/04/2021
-- Autor(es) .............. Micaella Lorraine Gouveia de Lima
-- Banco de Dados ......... MySQL
-- Banco de Dados(nome) ... aula6exer4Evolucao2
--
--
-- PROJETO = 01 Base de Dados
--         = 08 Tabelas
--         = 2 Usuários
-- -----------------------------------------------------------------

USE aula6exer4Evolucao2;

DROP TABLE trabalha;
DROP TABLE PROJETO;
DROP TABLE localizacao;
DROP TABLE DEPENDENTE;
DROP TABLE supervisiona;
DROP TABLE gerencia;
DROP TABLE EMPREGADO;
DROP TABLE DEPARTAMENTO;