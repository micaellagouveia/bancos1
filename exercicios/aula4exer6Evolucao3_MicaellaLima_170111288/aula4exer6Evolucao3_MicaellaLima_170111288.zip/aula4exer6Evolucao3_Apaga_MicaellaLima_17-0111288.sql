-- --------     << DETRAN >>     ------------
-- 
-- SCRIPT DE APAGAR (DDL)
-- 
-- Data Criacao ...........: 22/03/2021
-- Autor(es) ..............: Micaella Lorraine Gouveia de Lima
-- Banco de Dados .........: MySQL 8.0.23
-- Banco de Dados(nome) ...: aula4exer6Evolucao3
-- 
-- PROJETO => 01 Base de Dados
--         => 09 Tabelas
-- -----------------------------------------------------------------

USE aula4exer6Evolucao3;

DROP TABLE INFRACAO;
DROP TABLE TIPOINFRACAO;
DROP TABLE LOCAL;
DROP TABLE AGENTE;
DROP TABLE VEICULO;
DROP TABLE CATEGORIA;
DROP TABLE MODELO;
DROP TABLE telefone;
DROP TABLE PROPRIETARIO;