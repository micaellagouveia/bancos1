-- --------     << aula9extra1evolucao2 >>     ------------
-- 
-- SCRIPT DE CRIACAO (DDL)
-- 
-- Data Criacao ...........: 09/04/2021
-- Autor(es) ..............: Micaella Lorraine Gouveia de Lima
-- Banco de Dados .........: MySQL 8.0.23
-- Banco de Dados(nome) ...: aula9extra1evolucao2
-- 
-- PROJETO => 01 Base de Dados
--         => 02 Tabelas
-- -----------------------------------------------------------------

USE aula9extra1;

DROP TABLE CIDADE;
DROP TABLE ESTADO;